package models;

public class IdealParticleSystem extends ParticleSystem{
    public IdealParticleSystem(){
        super();
        System.out.println("Instance of Ideal Particle System Created.");
    }

}